<?php 
require "meekrodb/db.class.php";
DB::$user = 'matvey';
DB::$password = '15112016';
DB::$dbName = 'librusec';
DB::$encoding = 'utf8'; // defaults to latin1 if omitted
