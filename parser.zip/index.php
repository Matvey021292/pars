<?php 
header('Content-Type: text/html; charset=utf-8');
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require 'function.php';
require 'phpQuery-onefile.php';
require 'db_conf.php';
require 'db_function.php';
require 'flibusta.php';
require 'flibusta_author.php';




// require 'add_image_jpg_databases.php';
// require 'single_page_parser.php';
// require 'function_parser.php';
// require 'create_author_slug.php';
