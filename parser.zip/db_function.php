<?php

// $accounts = DB::query("SELECT * FROM `bk_author`");
// debug($accounts);
// foreach ($accounts as $account) {
//   echo $account['title'];
// }


function insert_db($arr){
	DB::insert('bk_author', array(
		'title' => $arr['title'],
		'link' => $arr['link'],
	));
}

function if_book_isset($url){
	$book = DB::queryFirstRow("SELECT `book` FROM `bk_book` WHERE link=%s", $url);
	if(!empty($book)){
		return $book['book'];
	}else{
		return false;
	}
}


function get_author($title){
	$author = DB::queryFirstRow("SELECT `id` FROM `bk_author` WHERE title=%s", $title);
	if(!empty($author)) return $author['id'];
}


function update_author_link($id, $link){
	DB::update('bk_author', array(
		'link' => $link
	), "id=%s", $id);

}

function get_author_inform($id){
	$author = DB::queryFirstRow("SELECT `id` FROM `bk_author_inform` WHERE id_author=%s", $id);
	if(!empty($author)) return $author['id'];
}

function get_book_content_db($id){
	$format = DB::queryFirstRow("SELECT `id` FROM `bk_book_content` WHERE format_id=%s", $id);
	if(!empty($format)) return $format['id'];
}

function insert_book_content_db($book_id, $content){
	DB::insert('bk_book_content', array(
		'format_id' 	  => $book_id,
		'content' => $content,
	));
}


function insert_author_inform($id, $name, $img = '', $desc = ''){
	DB::insert('bk_author_inform', array(
		'id_author'   => $id,
		'image' 	  => $img,
		'desc_author' => $desc,
		'name'  	  => $name,
	));
}

function get_category($title, $author_id){
	$category = DB::queryFirstRow("SELECT `id` FROM `bk_categoty` WHERE caregory=%s AND author_id=%s" , $title, $author_id);
	if(!empty($category)) return $category['id'];
}

function insert_category($id, $name, $category_slug){
	DB::insert('bk_categoty', array(
		'author_id'   => $id,
		'caregory' 	  => $name,
		'category_slug'  	  => $category_slug,
	));
}

function get_book($title, $slug){
	$book = DB::queryFirstRow("SELECT `id` FROM `bk_book` WHERE book=%s AND link=%s", $title, $slug);
	if(!empty($book)) return $book['id'];
}

function insert_book($author_id, $category_book_id, $category_id = 0, $book, $link, $slug){
	DB::insert('bk_book', array(
		'author_id'   => $author_id,
		'category_book_id' 	  => $category_book_id,
		'category_id' 	  => $category_id,
		'book' => $book,
		'link'  	  => $link,
		'slug' => $slug,
		
	));
}


function get_rating_db($book_id){
	$rating_id = DB::queryFirstRow("SELECT `id` FROM `bk_rating` WHERE book_id=%s", $book_id);
	if(!empty($rating_id)) return $rating_id['id'];
}

function insert_rating_db($book_id, $rating_count, $user_count){
	DB::insert('bk_rating', array(
		'book_id'        => $book_id,
		'rating_count'   => $rating_count,
		'user_count' 	  => $user_count,
	));
}

function get_relationship_category($category, $book_id){
	$category_id = DB::queryFirstRow("SELECT `id` FROM `bk_category_relationship` WHERE category_id=%s AND book_id=%s",$category, $book_id);
	if(!empty($category_id)) return $category_id['id'];
}


function insert_relationship_category($category, $book_id){
	DB::insert('bk_category_relationship', array(
		'category_id' => $category,
		'book_id' 	  => $book_id,
	));
}

function get_category_book($cat){
	$category = DB::queryFirstRow("SELECT `id` FROM `bk_categoty_book` WHERE category=%s", $cat);
	if(!empty($category)) return $category['id'];
}

function insert_category_book($category, $category_slug){
	DB::insert('bk_categoty_book', array(
		'category' 	=> $category,
		'slug' 	  	=> $category_slug,
	));
}

function get_book_format($book_id,$fomat){
	$format = DB::queryFirstRow("SELECT `id` FROM `bf_book_format` WHERE book_id=%s AND fomat=%s", $book_id, $fomat);
	if(!empty($format)) return $format['id'];
}


function insert_book_format($book_id, $fomat, $link, $file_name = 'more'){
	DB::insert('bf_book_format', array(
		'book_id'   => $book_id,
		'fomat' 	=> $fomat,
		'link' 	  	=> $link,
		'slug'   	=> $file_name,
	));
}


function get_book_desc($book_id){
	$format = DB::queryFirstRow("SELECT `id` FROM `bk_book_description` WHERE book_id=%s", $book_id);
	if(!empty($format)) return $format['id'];
}

function insert_book_desc($book_id, $desc, $img, $size){
	DB::insert('bk_book_description', array(
		'book_id'   => $book_id,
		'book_desc' => $desc,
		'book_img' 	=> $img,
		'size' => $size,
	));
}

