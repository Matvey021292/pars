<?php

echo "1\r\n";
echo "2\r\n";
echo "3\r\n";